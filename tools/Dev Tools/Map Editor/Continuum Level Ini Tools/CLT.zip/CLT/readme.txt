You are reading the readme for Continuum Level Tool, a program by Team 12, BaK- and 2Dragons (mostly Bak-).

Double click "CLT.jar" to start the program. You will need JRE (Java Runtime Environment) which is a free download at http://java.sun.com/j2se/1.5.0/download.jsp

If it's not working when you double click, find the path of Java.exe (search in program files\Java\) and do run
"java.exe -jar CLT.jar"

Some parts of this program aren't made by us, namely:

Continuum graphics
(by VIE?)

JAI (Java Advanced Imaging)
for more info on distributing products with JAI I'm going to refer you to java.sun.com and hope you find all the legal stuff there.

This software (with the exception of the above parts) and it's source are distrubuted under GPL and does not come with any warrenty at all... not even that it works! For a more official statement of GPL see license.txt

Updates:
8-5-04 Initial Release

8-6-04 Fixed region issues brought forward by Dr Brain

1-1-05 Increased draw speed while decreasing memory usage, Added square and squarefill tools, added support for eLVL ATTR and REGN tags, as well as additional region option made availble through eLVL.

3-18-05 Added cross platform support by encorperating X-LvzToolkit into the editor. Fixed LvzImageWindow disappearing forever bug.

7-23-05 Added a buttload of features as well as some bug fixes. Most notably we have undo/redo, support for extra continuum tiles, retiling, and a bunch more selection specific features (flipping, rotating, eztiling to name a few).

7-25-05 Fixed the special tiles not erasing bug and added a delete option for selections

7-26-05 Fixed the Apply EZ Tile occasionally not working bug

8-10-05 Fixed the region issues (again?) brought forward by Dr Brain and layout issue with the region window discussed by Smong

8-25-05 Fixed More Layout Issues brought forward by Smong

8-30-05 Added alternate hotkeys for zooming in preferences; using the menu zoom now zooms to the center of the screen. Use of the radar will be remembered across sessions.

10-24-05 Added JPEG Rememberence for your jpeg images (they will no longer be forced to be PNGs), Added automatic tiling (like Tile Majik)

11-7-05 Added support for multiple walls to be defined

11-21-05 Added Ellipse and Ellipse fill tools. Added Fill tool. Program will attempt to read walls from the map when you open a map.

11-28-05 Walls will automatically be imported for maps. Also you can select multiple lvz objects using both the selection and lvz_selection tool. You can move objects around just by dragging them using the lvz objects tool.

12-06-05 Added Manual and fixed automatic wall recognition

11-7-06 Added a menu item for changing the lvz selection mode (select only top lvz is back!), as well as enabling dragging. Fixed the freeze when opening maps with custom eLVL chunks.

9-16-07 Auto detects working directory so you can associate .lvl types with CLT (change by Cerium)