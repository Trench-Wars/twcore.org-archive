Drake Continuum Map Editor 3.4.15

=== HOW TO INSTALL ===
You need administrator priviledges to install DCME. A future release might eventually make installing easi
Windows XP and older
---Unzip all the contents of the downloaded file in the folder of your choice.
---Double-click on dcme_install.bat to execute it. It will register the DLL and OCX files.
---Run DCME.

Windows Vista/7
---Unzip all the contents of the downloaded file in the folder of your choice
---Right-click on 'dcme_install.bat' and select 'Execute as administrator'. It will register the DLL and OCX files.
-Run DCME.

=== HOW TO UNINSTALL ===
---Execute 'dcme_uninstall.bat' as administrator to unregister the DLL and OCX files.
---Delete DCME as you please.