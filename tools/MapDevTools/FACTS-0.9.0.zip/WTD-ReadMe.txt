;WallTile=0:4,5,6,7,23,24,25,26,42,43,44,45,61,62,63,64,1,39,77,58

Each line in a WallTile Definition (.wtd) that
begins with "WallTile=" represents one WallTile.

The first number (between the '=' and the ':') is
the number of the WallTile being specified.  Valid
WallTile numbers are 0-31

The list of numbers after the ':' are the tiles
that make up the WallTile.  If there are more
than 20 numbers, only the first 20 are used; if
there are 16 of fewer, the definition contains
no diagonals.  (FACTS will fill any empty spaces
with empty tiles.)

Valid tile values are 0-190.  Any invalid tile
is changed to the empty tile (value 0).
