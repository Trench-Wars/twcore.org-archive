
  !!! NOTE !!!
    If you get an error when you try to run FACTS, you
    are probably missing Comdlg32.ocx.  Download and run
    Comdlg32.ocx.exe, and it will install the file for you.
    
  !!! NOTE !!!
    As of FACTS-0.9.0pre4, you now also need mscomctl.ocx,
    which is available in ComCtl32.ocx.exe.  But, hey, now
    the UI's nicer looking.

Latest Versions:

  FACTS-0.9.0
    Yes, it's finally here!  Enjoy the new features
    (the changelog has all the information you'd
    ever want or need), and if this doesn't do all
    the things you want, remember to send your new
    suggestions in, since the next development tree
    starts shortly.  (E-mail subspace@clayjar.com
    with suggestions or bug reports.)

Old versions:

  FACTS-0.9.0-final
  FACTS-0.9.0pre16
  FACTS-0.9.0pre15
  FACTS-0.9.0pre14
  FACTS-0.9.0pre13
  FACTS-0.9.0pre12
  FACTS-0.9.0pre11
  FACTS-0.9.0pre10
  FACTS-0.9.0pre9
  FACTS-0.9.0pre8
  FACTS-0.9.0pre7
  FACTS-0.9.0pre6
  FACTS-0.9.0pre5
  FACTS-0.9.0pre4
  FACTS-0.9.0pre3
  FACTS-0.9.0pre2
  FACTS-0.9.0pre1
  FACTS-0.8.0
  FACTS-0.8.0pre18
  FACTS-0.8.0pre17
  FACTS-0.8.0pre16
  FACTS-0.8.0pre15
  FACTS-0.8.0pre14
  FACTS-0.8.0pre13
  FACTS-0.8.0pre12
  FACTS-0.8.0pre11
  FACTS-0.8.0pre10
  FACTS-0.8.0pre9
  FACTS-0.8.0pre8
  FACTS-0.8.0pre7
  FACTS-0.8.0pre6
  FACTS-0.7.1pre5
  FACTS-0.7.1pre4
  FACTS-0.7.1pre3
  FACTS-0.7.1pre2
  FACTS-0.7.1pre1
  FACTS-0.7.0
  FACTS-0.7.0pre5
  FACTS-0.7.0pre4
  FACTS-0.7.0pre3
  FACTS-0.7.0pre2
  FACTS-0.7.0pre1
  FACTS-0.6.1
  FACTS-0.6.0
  FACTS-0.5.0
  FACTS-0.4.*
  FACTS-0.3.0
  BMP2LVLa
  BMP2LVL
